#include <SFML/Graphics.hpp>
#include <time.h>
#include <iostream>
using namespace std;
using namespace sf;
int main()
{
   srand(time(0));
int ts = 54; //tile size
Vector2i offset(10,24);
   srand(time(0));
    RenderWindow app(VideoMode(740,480), "Animalia");
    app.setFramerateLimit(60);
    Texture t1,t2;
    t1.loadFromFile("images/background.png");
    t2.loadFromFile("images/animals.png");
    Sprite background(t1), animals(t2);
    Event e;
   
    int animalXPos[9][9];
    int animalYPos[9][9];
    int animalType[9][9];
    int match[9][9];
    int grid [9][9];
    for(int i=0;i<=8;i++)
      for (int j = 0; j <=8; j++)
      {
        animalType[i][j] = rand() % 7;

      }
    
    
    int i=1;
    while(i<=8){
    int j=1;
    while(j<=8){
    
          animalType[i][j]=rand()%7;
          animalXPos[i][j] = i*ts;
          animalYPos[i][j] = j*ts;
          j++;
    }
    i++;
    }
    
    int pressedCount=0;
    int onStartSwapPos[2];
    int onEndSwapPost[2];
   
    
    
    while (app.isOpen()){
    
    while (app.pollEvent(e))
    {
    
    if (e.type == Event::Closed)
                app.close();
                if (e.type == Event::MouseButtonPressed)
                if (e.key.code == Mouse::Left){
                
                 if(e.key.code==Keyboard::Escape)
                   	app.close();
                
                pressedCount++;
                Vector2i mousePosition = Mouse::getPosition(app)-offset;
                
                if(pressedCount == 1){
                onStartSwapPos[0]= mousePosition.x/ts+1; // preserve x axis
                onStartSwapPos[1]= mousePosition.y/ts+1; // preserve y axis
                }
                if(pressedCount == 2){
                
                onEndSwapPost[0]= mousePosition.x/ts+1; // preserve x axis
                onEndSwapPost[1]= mousePosition.y/ts+1; // preserve y axis
                
                }
                
                
                if(( onEndSwapPost[0]-onStartSwapPos[0] ==  1 || onEndSwapPost[0]-onStartSwapPos[0] ==  -1 )
                ||
                ( onEndSwapPost[1]-onStartSwapPos[1] ==  1 || onEndSwapPost[1]-onStartSwapPos[1] ==  -1) 
                )
                {
                pressedCount=0;
                }
                else
                  {
                     pressedCount = 1;
                  }
                
                }
   //Match finding
   for(int i=1;i<=8;i++)
   for(int j=1;j<=8;j++)
   {
    if (animalType[i][j]==animalType[i+1][j])
    if (animalType[i][j]==animalType[i-1][j])
     for(int n=-1;n<=1;n++) 
      match[i+n][j]++;

    if (grid[i][j]==grid[i][j+1])
    if (grid[i][j]==grid[i][j-1])
     for(int n=-1;n<=1;n++)
      match[i][j+n]++;
}

bool isMoving =false;
bool isSwap= false;
int click=0;
Vector2i pos;
    while (app.isOpen())
    {
        Event e;
        while (app.pollEvent(e))
        {
            if (e.type == Event::Closed)
                app.close();
                   
            if (e.type == Event::MouseButtonPressed)
                if (e.key.code == Mouse::Left)
                {
                   if (!isSwap && !isMoving) 
                  click++;
                   pos = Mouse::getPosition(app)-offset;
                }
         }


    app.draw(background);    
    
    
    for (int i=1;i<=8;i++){
     for (int j=1;j<=8;j++) {
        int type = animalType[i][j];
        animals.setTextureRect(IntRect(type*49,0,49,49));
        
        int xcord=animalXPos[i][j];
        int ycord=animalYPos[i][j]; 
        animals.setPosition(xcord,ycord);
        
        animals.move(offset.x-ts,offset.y-ts);
        app.draw(animals);
      }
    }
       
    app.display();
    }
    }
    return 0;
}}
